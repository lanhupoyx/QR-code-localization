//
// Created by xiang on 2022/7/28.
//

#ifndef SLAM_IN_AUTO_DRIVING_GLOBAL_FLAGS_H
#define SLAM_IN_AUTO_DRIVING_GLOBAL_FLAGS_H

namespace sad::global {

extern bool FLAG_EXIT;  // 退出程序标志

}

#endif  // SLAM_IN_AUTO_DRIVING_GLOBAL_FLAGS_H
