//
// Created by xiang on 2022/7/28.
//

#include "common/global_flags.h"

namespace sad::global {

bool FLAG_EXIT = false;
}